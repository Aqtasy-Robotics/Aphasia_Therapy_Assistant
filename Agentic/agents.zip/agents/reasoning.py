from typing import Any, Dict

from openai import OpenAI
import anthropic

from config import config


def _get_openai_client() -> OpenAI:
    if not config.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is not set for OpenAI LLM calls.")
    return OpenAI(api_key=config.openai_api_key)


def _get_anthropic_client() -> anthropic.Anthropic:
    if not config.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY is not set for Anthropic LLM calls.")
    return anthropic.Anthropic(api_key=config.anthropic_api_key)


def _build_prompt(
    error_report: Dict[str, Any],
    semantic_report: Dict[str, Any],
    target_word: str,
) -> str:
    phonemes_target = error_report.get("phonemes_target", [])
    phonemes_transcribed = error_report.get("phonemes_transcribed", [])
    errors = error_report.get("errors", [])
    match_score = error_report.get("match_score", 0.0)
    primary_error = error_report.get("primary_error_type", "Unknown")

    semantic_type = semantic_report.get("semantic_error_type", "Unknown")
    semantic_similarity = semantic_report.get("semantic_similarity", 0.0)

    return (
        "You are an expert speech and language therapist.\n"
        "Your tone is calm, encouraging, and professional.\n\n"
        f"Target word: {target_word}\n"
        f"Target phonemes: {phonemes_target}\n"
        f"Attempt phonemes: {phonemes_transcribed}\n"
        f"Phonological match score: {match_score:.2f}\n"
        f"Primary phonological error: {primary_error}\n"
        f"Phonological details: {errors}\n\n"
        f"Semantic error type: {semantic_type}\n"
        f"Semantic similarity score: {semantic_similarity:.2f}\n\n"
        "Explain clearly:\n"
        "1. Whether the sounds were incorrect, the meaning was incorrect, or both.\n"
        "2. If the meaning was close but not exact, explain how.\n"
        "3. Give 1–2 concrete tips to improve pronunciation or word choice.\n"
        "Keep the response under 5 sentences.\n"
    )

def _call_llm(prompt: str) -> str:
    if config.llm_provider == "anthropic":
        client = _get_anthropic_client()
        resp = client.messages.create(
            model=config.llm_model or "claude-3-5-sonnet-20240620",
            max_tokens=350,
            messages=[{"role": "user", "content": prompt}],
        )
        # Anthropic returns content as a list of blocks
        text_parts = [b.text for b in resp.content if getattr(b, "text", None)]
        return "".join(text_parts).strip()
    else:
        client = _get_openai_client()
        chat = client.chat.completions.create(
            model=config.llm_model or "gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are a supportive speech therapist for children and adults.",
                },
                {"role": "user", "content": prompt},
            ],
            max_tokens=350,
        )
        return chat.choices[0].message.content.strip()  # type: ignore[return-value]


def run_reasoning(
    target_word: str,
    error_report: Dict[str, Any],
    semantic_report: Dict[str, Any],
    is_perfect_match: bool,
) -> Dict[str, Any]:
    """
    Turn phonological + semantic analysis into therapist-style feedback.
    """

    if is_perfect_match and semantic_report["semantic_error_type"] == "Semantic Paraphasia":
        # Rare but important edge case
        feedback_text = (
            f"You pronounced '{target_word}' clearly, but the word you said had a slightly different meaning. "
            "Try focusing on choosing the exact word that matches the idea you want to express."
        )
        return {"feedback_text": feedback_text, "is_perfect_match": False}

    if is_perfect_match:
        feedback_text = (
            f"Great job! Your pronunciation and word choice for '{target_word}' were clear and accurate. "
            "Keep practicing it just like that."
        )
        return {"feedback_text": feedback_text, "is_perfect_match": True}

    prompt = _build_prompt(error_report, semantic_report, target_word)

    try:
        feedback_text = _call_llm(prompt)
    except Exception as exc:
        feedback_text = (
            "You were close, but there were some differences in the sounds or meaning of the word. "
            "Try slowing down and focusing on each sound and the exact word you want to say."
            f" (Technical details: {exc})"
        )

    return {"feedback_text": feedback_text, "is_perfect_match": False}
